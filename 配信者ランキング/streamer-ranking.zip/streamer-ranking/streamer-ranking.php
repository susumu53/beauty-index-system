<?php
/**
 * Plugin Name: Streamer Ranking
 * Plugin URI:  https://example.com/
 * Description: TwitchとYouTubeの配信者ランキングをAI検索で自動取得し、並び替え可能な表で表示します。ショートコード [streamer_ranking] で埋め込み可能。
 * Version:     1.0.0
 * Author:      Your Name
 * License:     GPL-2.0+
 * Text Domain: streamer-ranking
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'SR_VERSION',    '1.0.0' );
define( 'SR_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SR_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/* -------------------------------------------------------
   1. 設定ページ
------------------------------------------------------- */
add_action( 'admin_menu', 'sr_add_admin_menu' );
function sr_add_admin_menu() {
    add_options_page(
        '配信者ランキング設定',
        '配信者ランキング',
        'manage_options',
        'streamer-ranking',
        'sr_settings_page'
    );
}

add_action( 'admin_init', 'sr_register_settings' );
function sr_register_settings() {
    register_setting( 'sr_settings_group', 'sr_anthropic_api_key', [
        'sanitize_callback' => 'sanitize_text_field',
    ] );
    register_setting( 'sr_settings_group', 'sr_cache_minutes', [
        'sanitize_callback' => 'absint',
        'default'           => 60,
    ] );
}

function sr_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    ?>
    <div class="wrap">
        <h1>配信者ランキング設定</h1>
        <form method="post" action="options.php">
            <?php settings_fields( 'sr_settings_group' ); ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="sr_anthropic_api_key">Anthropic APIキー</label></th>
                    <td>
                        <input
                            type="password"
                            id="sr_anthropic_api_key"
                            name="sr_anthropic_api_key"
                            value="<?php echo esc_attr( get_option( 'sr_anthropic_api_key' ) ); ?>"
                            class="regular-text"
                        />
                        <p class="description">
                            <a href="https://console.anthropic.com/account/keys" target="_blank">Anthropic Console</a> でAPIキーを取得してください。
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="sr_cache_minutes">キャッシュ時間（分）</label></th>
                    <td>
                        <input
                            type="number"
                            id="sr_cache_minutes"
                            name="sr_cache_minutes"
                            value="<?php echo esc_attr( get_option( 'sr_cache_minutes', 60 ) ); ?>"
                            min="5"
                            max="1440"
                            class="small-text"
                        />
                        <p class="description">APIの呼び出し頻度を抑えるためにデータをキャッシュします（推奨: 60分）。</p>
                    </td>
                </tr>
            </table>
            <?php submit_button( '設定を保存' ); ?>
        </form>
        <hr>
        <h2>使い方</h2>
        <p>投稿・固定ページにショートコードを貼り付けるだけで表示されます：</p>
        <code>[streamer_ranking]</code>
        <p>オプション付きの例：</p>
        <code>[streamer_ranking platform="Twitch" limit="10"]</code>
        <p><strong>platform</strong>: <code>all</code> / <code>Twitch</code> / <code>YouTube</code>（デフォルト: all）<br>
           <strong>limit</strong>: 表示件数（デフォルト: 20）</p>
    </div>
    <?php
}

/* -------------------------------------------------------
   2. REST API エンドポイント（APIコールはサーバーサイド）
------------------------------------------------------- */
add_action( 'rest_api_init', 'sr_register_rest_route' );
function sr_register_rest_route() {
    register_rest_route( 'streamer-ranking/v1', '/fetch', [
        'methods'             => 'GET',
        'callback'            => 'sr_rest_fetch',
        'permission_callback' => '__return_true',
        'args'                => [
            'platform' => [
                'default'           => 'all',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'limit' => [
                'default'           => 20,
                'sanitize_callback' => 'absint',
            ],
        ],
    ] );
}

function sr_rest_fetch( WP_REST_Request $request ) {
    $platform = $request->get_param( 'platform' );
    $limit    = min( (int) $request->get_param( 'limit' ), 30 );

    $cache_key = 'sr_data_' . md5( $platform . '_' . $limit );
    $cached    = get_transient( $cache_key );
    if ( $cached !== false ) {
        return rest_ensure_response( $cached );
    }

    $api_key = get_option( 'sr_anthropic_api_key', '' );
    if ( empty( $api_key ) ) {
        return new WP_Error( 'no_api_key', 'Anthropic APIキーが設定されていません。管理画面 > 設定 > 配信者ランキング から設定してください。', [ 'status' => 503 ] );
    }

    $platform_note = ( $platform !== 'all' ) ? "Focus only on {$platform} streamers." : 'Include both Twitch and YouTube streamers.';

    $body = wp_json_encode( [
        'model'      => 'claude-sonnet-4-20250514',
        'max_tokens' => 1500,
        'tools'      => [ [ 'type' => 'web_search_20250305', 'name' => 'web_search' ] ],
        'system'     => 'You are a data assistant. Search the web for current top streamers (2025-2026). ' .
                        $platform_note .
                        ' Return ONLY a raw JSON object — no markdown, no backticks, no explanation. ' .
                        'Format: {"updated":"YYYY-MM","source":"brief source","streamers":[{"rank":1,"name":"...","platform":"Twitch or YouTube","followers":18.5,"peak_viewers":295,"category":"カテゴリ（日本語）"}]}' .
                        ' followers = millions (number), peak_viewers = thousands (number). Return ' . $limit . ' streamers.',
        'messages'   => [
            [ 'role' => 'user', 'content' => "Get top {$limit} streamers. Return only JSON." ],
        ],
    ] );

    $response = wp_remote_post( 'https://api.anthropic.com/v1/messages', [
        'timeout' => 60,
        'headers' => [
            'x-api-key'         => $api_key,
            'anthropic-version' => '2023-06-01',
            'anthropic-beta'    => 'web-search-20250305',
            'Content-Type'      => 'application/json',
        ],
        'body' => $body,
    ] );

    if ( is_wp_error( $response ) ) {
        return new WP_Error( 'api_error', $response->get_error_message(), [ 'status' => 502 ] );
    }

    $status = wp_remote_retrieve_response_code( $response );
    if ( $status !== 200 ) {
        $msg = wp_remote_retrieve_body( $response );
        return new WP_Error( 'api_error', "Anthropic API エラー ({$status}): {$msg}", [ 'status' => $status ] );
    }

    $api_data = json_decode( wp_remote_retrieve_body( $response ), true );
    $text     = '';
    foreach ( $api_data['content'] ?? [] as $block ) {
        if ( isset( $block['type'] ) && $block['type'] === 'text' ) {
            $text .= $block['text'];
        }
    }

    $text  = preg_replace( '/```json|```/', '', $text );
    $start = strpos( $text, '{' );
    $end   = strrpos( $text, '}' );
    if ( $start === false || $end === false ) {
        return new WP_Error( 'parse_error', 'APIレスポンスのJSON解析に失敗しました。', [ 'status' => 500 ] );
    }

    $parsed = json_decode( substr( $text, $start, $end - $start + 1 ), true );
    if ( ! $parsed ) {
        return new WP_Error( 'parse_error', 'JSONデコードに失敗しました。', [ 'status' => 500 ] );
    }

    $cache_minutes = (int) get_option( 'sr_cache_minutes', 60 );
    set_transient( $cache_key, $parsed, $cache_minutes * MINUTE_IN_SECONDS );

    return rest_ensure_response( $parsed );
}

/* -------------------------------------------------------
   3. ショートコード
------------------------------------------------------- */
add_shortcode( 'streamer_ranking', 'sr_shortcode' );
function sr_shortcode( $atts ) {
    $atts = shortcode_atts( [
        'platform' => 'all',
        'limit'    => 20,
    ], $atts, 'streamer_ranking' );

    $platform = sanitize_text_field( $atts['platform'] );
    $limit    = absint( $atts['limit'] );

    wp_enqueue_style(  'sr-style',  SR_PLUGIN_URL . 'assets/style.css',  [], SR_VERSION );
    wp_enqueue_script( 'sr-script', SR_PLUGIN_URL . 'assets/script.js', [], SR_VERSION, true );

    wp_localize_script( 'sr-script', 'srConfig', [
        'restUrl'  => esc_url_raw( rest_url( 'streamer-ranking/v1/fetch' ) ),
        'nonce'    => wp_create_nonce( 'wp_rest' ),
        'platform' => $platform,
        'limit'    => $limit,
    ] );

    ob_start();
    ?>
    <div id="sr-widget" class="sr-widget" data-platform="<?php echo esc_attr( $platform ); ?>" data-limit="<?php echo esc_attr( $limit ); ?>">
        <div class="sr-header">
            <div class="sr-title-wrap">
                <h2 class="sr-title">配信者ランキング</h2>
                <p class="sr-subtitle" id="sr-last-updated">取得中...</p>
            </div>
            <div class="sr-filters" id="sr-filters">
                <?php if ( $platform === 'all' ) : ?>
                <button class="sr-btn active" data-p="all">すべて</button>
                <button class="sr-btn" data-p="Twitch">Twitch</button>
                <button class="sr-btn" data-p="YouTube">YouTube</button>
                <?php endif; ?>
            </div>
        </div>

        <div class="sr-loading" id="sr-loading">
            <div class="sr-spinner"></div>
            <p id="sr-loading-msg">データを検索中...</p>
        </div>

        <div class="sr-error" id="sr-error" style="display:none;">
            <p id="sr-error-msg"></p>
            <button class="sr-retry-btn" onclick="srRetry()">再取得</button>
        </div>

        <div id="sr-table-wrap" style="display:none;">
            <div class="sr-table-scroll">
                <table class="sr-table">
                    <thead>
                        <tr>
                            <th class="sr-sortable" data-col="rank">#</th>
                            <th class="sr-sortable" data-col="name">配信者名</th>
                            <th class="sr-sortable" data-col="platform">プラットフォーム</th>
                            <th class="sr-sortable sr-num" data-col="followers">フォロワー</th>
                            <th class="sr-sortable sr-num" data-col="peak_viewers">最高視聴者数</th>
                            <th class="sr-sortable" data-col="category">カテゴリ</th>
                        </tr>
                    </thead>
                    <tbody id="sr-tbody"></tbody>
                </table>
            </div>
            <p class="sr-note" id="sr-note"></p>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
